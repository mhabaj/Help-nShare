<?php

/* test.txt */
class __TwigTemplate_3e330290827e721e33c5822bb1b7d330513c280ca28aa8535212b42d8c92101a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Subject: phpBB est correctement configuré pour envoyer des e-mails

Bonjour ";
        // line 3
        echo (isset($context["USERNAME"]) ? $context["USERNAME"] : null);
        echo ",

Félicitations ! Si vous recevez ce message cela signifie que phpBB est correctement configuré pour envoyer les e-mails.

Dans le cas où vous auriez besoin d’assistance, veuillez visiter :
- le forum de support phpBB (en anglais) - https://www.phpbb.com/community/
- le forum de support phpBB-fr.com (en français) - http://forums.phpbb-fr.com/

";
        // line 11
        echo (isset($context["EMAIL_SIG"]) ? $context["EMAIL_SIG"] : null);
    }

    public function getTemplateName()
    {
        return "test.txt";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 11,  23 => 3,  19 => 1,);
    }
}
/* Subject: phpBB est correctement configuré pour envoyer des e-mails*/
/* */
/* Bonjour {USERNAME},*/
/* */
/* Félicitations ! Si vous recevez ce message cela signifie que phpBB est correctement configuré pour envoyer les e-mails.*/
/* */
/* Dans le cas où vous auriez besoin d’assistance, veuillez visiter :*/
/* - le forum de support phpBB (en anglais) - https://www.phpbb.com/community/*/
/* - le forum de support phpBB-fr.com (en français) - http://forums.phpbb-fr.com/*/
/* */
/* {EMAIL_SIG}*/
