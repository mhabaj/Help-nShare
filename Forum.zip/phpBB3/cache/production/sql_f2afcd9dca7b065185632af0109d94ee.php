<?php exit; ?>
1505055563
SELECT * FROM phpbb_styles s WHERE s.style_id = 2
285
a:1:{i:0;a:8:{s:8:"style_id";s:1:"2";s:10:"style_name";s:7:"proflat";s:15:"style_copyright";s:17:"© Mazeltof, 2017";s:12:"style_active";s:1:"1";s:10:"style_path";s:7:"proflat";s:15:"bbcode_bitfield";s:4:"+Ng=";s:15:"style_parent_id";s:1:"1";s:17:"style_parent_tree";s:9:"prosilver";}}